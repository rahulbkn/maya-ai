import os
from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_BASE_URL = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1").rstrip("/")
MODEL = os.getenv("MAYA_MODEL", "openai/gpt-oss-120b")
TEMPERATURE = float(os.getenv("MAYA_TEMPERATURE", "0.7"))
MAX_TOKENS = int(os.getenv("MAYA_MAX_TOKENS", "1024"))
REASONING_EFFORT = os.getenv("MAYA_REASONING_EFFORT", "").strip()
APP_TOKEN = os.getenv("MAYA_APP_TOKEN", "")
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
