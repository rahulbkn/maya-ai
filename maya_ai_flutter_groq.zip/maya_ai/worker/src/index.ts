interface Env {
  GROQ_API_KEY: string;
  MAYA_APP_TOKEN: string;
  MAYA_MODEL?: string;
  GROQ_BASE_URL?: string;
  MAYA_TEMPERATURE?: string;
  MAYA_MAX_TOKENS?: string;
  MAYA_REASONING_EFFORT?: string;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface ChatRequestBody {
  messages: ChatMessage[];
  language: "en" | "hi";
  personality: string;
  memory: string[];
}

interface ToolCall {
  id?: string;
  function?: {
    name?: string;
    arguments?: string;
  };
}

interface GroqMessage {
  role: string;
  content: string | null;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
  name?: string;
}

interface GroqResponse {
  choices?: Array<{
    message?: {
      content?: string | null;
      tool_calls?: ToolCall[];
    };
    finish_reason?: string;
  }>;
}

interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

interface NewsResult {
  title: string;
  url: string;
  source: string;
  date: string;
}

interface WeatherData {
  city?: string;
  country?: string;
  temp_c?: number;
  feels_like_c?: number;
  humidity?: number;
  wind_kmh?: number;
  condition?: string;
  time?: string;
  error?: string;
}

const DEFAULT_MODEL = "openai/gpt-oss-120b";
const BROWSER_UA =
  "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

const CORS: Record<string, string> = {
  "access-control-allow-origin": "*",
  "access-control-allow-headers": "content-type, x-maya-token",
  "access-control-allow-methods": "GET, POST, OPTIONS",
};

const SAFETY_RULES = `
Safety rules you always follow:
- Never help with unauthorized hacking, password theft, malware, spyware, or accessing accounts/devices you do not own.
- Cybersecurity help is educational and defensive: concepts, secure coding, and exercises on isolated labs the user owns or is authorized to test.
- Never claim to have done something you did not do (e.g. opened an app or searched) unless the app confirmed it.
`;

const TOOLS = [
  {
    type: "function",
    function: {
      name: "web_search",
      description: "Search the internet for current information.",
      parameters: {
        type: "object",
        properties: { query: { type: "string" } },
        required: ["query"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_weather",
      description: "Get current weather for a city.",
      parameters: {
        type: "object",
        properties: { city: { type: "string" } },
        required: ["city"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_news",
      description: "Get latest news headlines on a topic.",
      parameters: {
        type: "object",
        properties: { topic: { type: "string" } },
        required: ["topic"],
      },
    },
  },
];

const WMO: Record<number, string> = {
  0: "clear sky",
  1: "mainly clear",
  2: "partly cloudy",
  3: "overcast",
  45: "fog",
  48: "fog",
  51: "light drizzle",
  53: "drizzle",
  55: "heavy drizzle",
  61: "light rain",
  63: "rain",
  65: "heavy rain",
  71: "light snow",
  73: "snow",
  75: "heavy snow",
  80: "rain showers",
  81: "rain showers",
  82: "violent rain showers",
  95: "thunderstorm",
  96: "thunderstorm with hail",
  99: "thunderstorm with hail",
};

class HttpError extends Error {
  readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...CORS,
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });
}

function safeEqual(left: string, right: string): boolean {
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i++) {
    diff |= left.charCodeAt(i) ^ right.charCodeAt(i);
  }
  return diff === 0;
}

function requireToken(request: Request, env: Env): void {
  if (!env.MAYA_APP_TOKEN) {
    throw new HttpError(503, "MAYA_APP_TOKEN is not configured on the server");
  }
  const token = request.headers.get("x-maya-token") ?? "";
  if (!safeEqual(token, env.MAYA_APP_TOKEN)) {
    throw new HttpError(401, "Invalid or missing app token");
  }
}

function numberValue(value: string | undefined, fallback: number): number {
  if (!value) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function buildSystemPrompt(language: string, personality: string, memory: string[]): string {
  const lang = language === "hi" ? "Hindi (Devanagari script)" : "English";
  const parts = [
    "You are MAYA, a friendly, capable female AI voice assistant inside the MAYA AI Android app.",
    `Reply in ${lang} unless the user clearly writes in another language.`,
    "Keep answers short and natural for speech: 1-3 sentences unless asked for detail. Avoid markdown and emojis.",
    `Personality: ${personality || "warm, calm, and helpful"}.`,
    SAFETY_RULES,
  ];
  if (memory.length) {
    parts.push("Facts the user approved you to remember:\n- " + memory.join("\n- "));
  }
  return parts.join("\n");
}

async function fetchWithTimeout(
  url: string,
  init: RequestInit = {},
  timeoutMs = 60000,
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

async function errorDetail(response: Response): Promise<string> {
  const text = await response.text();
  try {
    const data = JSON.parse(text) as {
      error?: { message?: string };
      detail?: string;
    };
    if (data.error?.message) return data.error.message.slice(0, 300);
    if (data.detail) return data.detail.slice(0, 300);
  } catch {}
  return (text || `HTTP ${response.status}`).slice(0, 300);
}

async function groqComplete(
  env: Env,
  messages: GroqMessage[],
  withTools: boolean,
): Promise<GroqResponse> {
  const base = (env.GROQ_BASE_URL || "https://api.groq.com/openai/v1").replace(/\/+$/, "");
  const payload: Record<string, unknown> = {
    model: env.MAYA_MODEL || DEFAULT_MODEL,
    messages,
    temperature: numberValue(env.MAYA_TEMPERATURE, 0.7),
    max_tokens: Math.max(1, Math.floor(numberValue(env.MAYA_MAX_TOKENS, 1024))),
  };
  if (withTools) payload.tools = TOOLS;
  if (env.MAYA_REASONING_EFFORT) payload.reasoning_effort = env.MAYA_REASONING_EFFORT;

  let response: Response;
  try {
    response = await fetchWithTimeout(
      `${base}/chat/completions`,
      {
        method: "POST",
        headers: {
          authorization: `Bearer ${env.GROQ_API_KEY}`,
          "content-type": "application/json",
        },
        body: JSON.stringify(payload),
      },
      60000,
    );
  } catch {
    throw new HttpError(502, "Cannot reach the Groq API from the server");
  }

  if (response.status === 400 && withTools) {
    const detail = await errorDetail(response);
    if (/tool|function/i.test(detail)) {
      return groqComplete(env, messages, false);
    }
    throw new HttpError(502, `Groq error: ${detail}`);
  }

  if (!response.ok) {
    throw new HttpError(502, `Groq error: ${await errorDetail(response)}`);
  }

  try {
    return (await response.json()) as GroqResponse;
  } catch {
    throw new HttpError(502, "Groq returned an invalid response");
  }
}

function decodeEntities(value: string): string {
  return value
    .replace(/&#x([0-9a-f]+);/gi, (match, hex: string) => {
      const code = parseInt(hex, 16);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    })
    .replace(/&#(\d+);/g, (match, decimal: string) => {
      const code = parseInt(decimal, 10);
      return Number.isFinite(code) ? String.fromCodePoint(code) : match;
    })
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");
}

function cleanText(value: string): string {
  const withoutCdata = value.replace(/<!\[CDATA\[/g, "").replace(/\]\]>/g, "");
  return decodeEntities(withoutCdata.replace(/<[^>]*>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
}

function xmlItems(xml: string): string[] {
  return xml.match(/<item(?:\s[^>]*)?>[\s\S]*?<\/item>/gi) ?? [];
}

function xmlValue(block: string, tag: string): string {
  const match = block.match(
    new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)</${tag}>`, "i"),
  );
  return match ? cleanText(match[1]) : "";
}

async function bingSearch(query: string, limit: number): Promise<SearchResult[]> {
  const url = `https://www.bing.com/search?q=${encodeURIComponent(query)}&format=rss&setlang=en`;
  const response = await fetchWithTimeout(
    url,
    {
      headers: {
        "user-agent": BROWSER_UA,
        accept: "application/rss+xml, application/xml, text/xml",
      },
    },
    15000,
  );
  if (!response.ok) throw new Error(`Search failed (${response.status})`);
  const xml = await response.text();
  return xmlItems(xml)
    .map((block) => ({
      title: xmlValue(block, "title"),
      url: xmlValue(block, "link"),
      snippet: xmlValue(block, "description"),
    }))
    .filter((item) => item.title && item.url)
    .slice(0, limit);
}

async function ddgAnswers(query: string, limit: number): Promise<SearchResult[]> {
  const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(
    query,
  )}&format=json&no_html=1&skip_disambig=1`;
  const response = await fetchWithTimeout(
    url,
    { headers: { accept: "application/json" } },
    12000,
  );
  if (!response.ok) return [];
  const data = (await response.json()) as {
    Heading?: string;
    AbstractText?: string;
    AbstractURL?: string;
    RelatedTopics?: unknown[];
  };
  const results: SearchResult[] = [];
  if (data.AbstractText && data.AbstractURL) {
    results.push({
      title: data.Heading || query,
      url: data.AbstractURL,
      snippet: data.AbstractText,
    });
  }
  const walk = (topics: unknown[]) => {
    for (const entry of topics) {
      if (!entry || typeof entry !== "object") continue;
      const topic = entry as {
        Text?: string;
        FirstURL?: string;
        Topics?: unknown[];
      };
      if (topic.FirstURL && topic.Text) {
        results.push({
          title: topic.Text,
          url: topic.FirstURL,
          snippet: topic.Text,
        });
      }
      if (Array.isArray(topic.Topics)) walk(topic.Topics);
    }
  };
  if (Array.isArray(data.RelatedTopics)) walk(data.RelatedTopics);
  const seen = new Set<string>();
  return results
    .filter((item) => {
      if (seen.has(item.url)) return false;
      seen.add(item.url);
      return true;
    })
    .slice(0, limit);
}

async function webSearch(query: string, limit = 5): Promise<SearchResult[]> {
  try {
    const results = await bingSearch(query, limit);
    if (results.length) return results;
  } catch {}
  const answers = await ddgAnswers(query, limit);
  if (!answers.length) throw new Error("No search results found");
  return answers;
}

async function googleNews(topic: string, limit: number): Promise<NewsResult[]> {
  const hindi = /[\u0900-\u097F]/.test(topic);
  const language = hindi ? "hi" : "en-IN";
  const edition = hindi ? "hi" : "en";
  const url = `https://news.google.com/rss/search?q=${encodeURIComponent(
    topic,
  )}&hl=${language}&gl=IN&ceid=IN:${edition}`;
  const response = await fetchWithTimeout(
    url,
    {
      headers: {
        "user-agent": BROWSER_UA,
        accept: "application/rss+xml, application/xml, text/xml",
      },
    },
    15000,
  );
  if (!response.ok) throw new Error(`News failed (${response.status})`);
  const xml = await response.text();
  return xmlItems(xml)
    .map((block) => {
      const link = xmlValue(block, "link");
      let source = xmlValue(block, "source");
      if (!source && link) {
        try {
          source = new URL(link).hostname.replace(/^www\./, "");
        } catch {}
      }
      return {
        title: xmlValue(block, "title"),
        url: link,
        source: source || "Google News",
        date: xmlValue(block, "pubDate"),
      };
    })
    .filter((item) => item.title && item.url)
    .slice(0, limit);
}

async function news(topic: string, limit = 5): Promise<NewsResult[]> {
  try {
    const results = await googleNews(topic, limit);
    if (results.length) return results;
  } catch {}
  const results = await webSearch(`${topic} news`, limit);
  return results.map((item) => {
    let source = "Web";
    try {
      source = new URL(item.url).hostname.replace(/^www\./, "");
    } catch {}
    return {
      title: item.title,
      url: item.url,
      source,
      date: "",
    };
  });
}

async function getWeather(city: string): Promise<WeatherData> {
  const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
    city,
  )}&count=1&language=en&format=json`;
  const geoResponse = await fetchWithTimeout(geoUrl, {}, 12000);
  if (!geoResponse.ok) throw new Error(`Weather lookup failed (${geoResponse.status})`);
  const geo = (await geoResponse.json()) as {
    results?: Array<{
      name?: string;
      country?: string;
      latitude?: number;
      longitude?: number;
    }>;
  };
  const place = Array.isArray(geo.results) ? geo.results[0] : undefined;
  if (!place || typeof place.latitude !== "number" || typeof place.longitude !== "number") {
    return { error: `City '${city}' not found` };
  }

  const params = new URLSearchParams({
    latitude: String(place.latitude),
    longitude: String(place.longitude),
    current:
      "temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m",
    timezone: "auto",
  });
  const weatherResponse = await fetchWithTimeout(
    `https://api.open-meteo.com/v1/forecast?${params.toString()}`,
    {},
    12000,
  );
  if (!weatherResponse.ok) throw new Error(`Weather failed (${weatherResponse.status})`);
  const weather = (await weatherResponse.json()) as {
    current?: {
      temperature_2m?: number;
      apparent_temperature?: number;
      relative_humidity_2m?: number;
      weather_code?: number;
      wind_speed_10m?: number;
      time?: string;
    };
  };
  const current = weather.current;
  if (!current) throw new Error("Weather data unavailable");

  return {
    city: place.name,
    country: place.country,
    temp_c: current.temperature_2m,
    feels_like_c: current.apparent_temperature,
    humidity: current.relative_humidity_2m,
    wind_kmh: current.wind_speed_10m,
    condition: WMO[Number(current.weather_code)] ?? "unknown",
    time: current.time,
  };
}

function stringArg(value: unknown, name: string): string {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${name} is required`);
  }
  return value.trim();
}

async function runTool(name: string, args: Record<string, unknown>): Promise<unknown> {
  if (name === "web_search") {
    return await webSearch(stringArg(args.query, "query"));
  }
  if (name === "get_weather") {
    return await getWeather(stringArg(args.city, "city"));
  }
  if (name === "get_news") {
    const topic =
      typeof args.topic === "string" && args.topic.trim() ? args.topic.trim() : "India";
    return await news(topic);
  }
  return { error: "unknown tool" };
}

function validateChat(payload: unknown): ChatRequestBody {
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new HttpError(422, "Invalid request body");
  }
  const data = payload as Record<string, unknown>;
  if (
    !Array.isArray(data.messages) ||
    data.messages.length < 1 ||
    data.messages.length > 40
  ) {
    throw new HttpError(422, "messages must contain 1-40 items");
  }
  const messages: ChatMessage[] = data.messages.map((entry) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
      throw new HttpError(422, "Invalid message");
    }
    const item = entry as Record<string, unknown>;
    const role = item.role;
    const content = item.content;
    if (role !== "user" && role !== "assistant") {
      throw new HttpError(422, "message role must be user or assistant");
    }
    if (typeof content !== "string" || content.length > 8000) {
      throw new HttpError(422, "message content is too long");
    }
    return { role: role as "user" | "assistant", content };
  });
  const language = data.language === "hi" ? "hi" : "en";
  const personality =
    typeof data.personality === "string" ? data.personality.slice(0, 300) : "";
  let memory: string[] = [];
  if (Array.isArray(data.memory)) {
    memory = data.memory
      .filter((entry) => typeof entry === "string")
      .map((entry) => (entry as string).slice(0, 500))
      .slice(0, 30);
  }
  return { messages, language, personality, memory };
}

async function handleChat(request: Request, env: Env): Promise<Response> {
  requireToken(request, env);
  if (!env.GROQ_API_KEY) {
    throw new HttpError(503, "GROQ_API_KEY is not configured on the server");
  }

  let payload: unknown;
  try {
    payload = await request.json();
  } catch {
    throw new HttpError(400, "Invalid JSON body");
  }
  const req = validateChat(payload);
  const system = buildSystemPrompt(req.language, req.personality, req.memory);
  const messages: GroqMessage[] = [{ role: "system", content: system }];
  for (const message of req.messages) {
    messages.push({ role: message.role, content: message.content });
  }
  const used: string[] = [];

  for (let round = 0; round < 4; round++) {
    const data = await groqComplete(env, messages, true);
    const choices = Array.isArray(data.choices) ? data.choices : [];
    if (!choices.length) {
      throw new HttpError(502, "Groq returned an empty response");
    }
    const choice = choices[0] ?? {};
    const message = choice.message ?? {};
    const toolCalls = Array.isArray(message.tool_calls) ? message.tool_calls : [];

    if (!toolCalls.length) {
      const content = typeof message.content === "string" ? message.content.trim() : "";
      if (!content) {
        if (choice.finish_reason === "length") {
          throw new HttpError(502, "AI reply was cut off. Increase MAYA_MAX_TOKENS.");
        }
        throw new HttpError(502, "AI returned an empty reply");
      }
      return json({ reply: content, used_tools: used });
    }

    messages.push({
      role: "assistant",
      content: typeof message.content === "string" ? message.content : null,
      tool_calls: toolCalls,
    });

    for (const call of toolCalls) {
      const fn = call.function ?? {};
      const name = typeof fn.name === "string" ? fn.name : "";
      const rawArgs = typeof fn.arguments === "string" && fn.arguments ? fn.arguments : "{}";
      used.push(name);
      let output: unknown;
      try {
        const args = JSON.parse(rawArgs) as unknown;
        if (!args || typeof args !== "object" || Array.isArray(args)) {
          throw new Error("invalid tool arguments");
        }
        output = await runTool(name, args as Record<string, unknown>);
      } catch (err) {
        output = { error: err instanceof Error ? err.message : "tool failed" };
      }
      messages.push({
        role: "tool",
        tool_call_id: typeof call.id === "string" ? call.id : "",
        name,
        content: JSON.stringify(output),
      });
    }
  }

  throw new HttpError(500, "Too many tool rounds");
}

const worker: ExportedHandler<Env> = {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: CORS });
    }
    const url = new URL(request.url);
    try {
      if (request.method === "GET" && url.pathname === "/health") {
        return json({
          status: "ok",
          ai_configured: Boolean(env.GROQ_API_KEY),
          model: env.MAYA_MODEL || DEFAULT_MODEL,
        });
      }
      if (request.method === "POST" && url.pathname === "/chat") {
        return await handleChat(request, env);
      }
      if (request.method === "GET" && url.pathname === "/search") {
        requireToken(request, env);
        const q = (url.searchParams.get("q") || "").trim();
        if (!q) throw new HttpError(422, "q is required");
        return json({ results: await webSearch(q) });
      }
      if (request.method === "GET" && url.pathname === "/weather") {
        requireToken(request, env);
        const city = (url.searchParams.get("city") || "").trim();
        if (!city) throw new HttpError(422, "city is required");
        return json(await getWeather(city));
      }
      if (request.method === "GET" && url.pathname === "/news") {
        requireToken(request, env);
        const topic = (url.searchParams.get("topic") || "India").trim() || "India";
        return json({ articles: await news(topic) });
      }
      return json({ detail: "Not found" }, 404);
    } catch (err) {
      if (err instanceof HttpError) {
        return json({ detail: err.message }, err.status);
      }
      console.error(err instanceof Error ? err.message : String(err));
      return json({ detail: "Internal server error" }, 500);
    }
  },
};

export default worker;
