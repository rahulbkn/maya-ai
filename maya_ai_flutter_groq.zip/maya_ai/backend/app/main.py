import asyncio
import json
from typing import Literal

import httpx
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field

from . import config, tools
from .prompts import build_system_prompt
from .security import rate_limit, require_app_token

app = FastAPI(title="MAYA AI Backend", version="0.2.0")
guard = [Depends(rate_limit), Depends(require_app_token)]

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Search the internet for current information.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get current weather for a city.",
            "parameters": {
                "type": "object",
                "properties": {"city": {"type": "string"}},
                "required": ["city"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_news",
            "description": "Get latest news headlines on a topic.",
            "parameters": {
                "type": "object",
                "properties": {"topic": {"type": "string"}},
                "required": ["topic"],
            },
        },
    },
]


class Message(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=8000)


class ChatRequest(BaseModel):
    messages: list[Message] = Field(min_length=1, max_length=40)
    language: Literal["en", "hi"] = "en"
    personality: str = Field(default="", max_length=300)
    memory: list[str] = Field(default_factory=list, max_length=30)


class ChatResponse(BaseModel):
    reply: str
    used_tools: list[str] = []


async def run_tool(name: str, args: dict):
    if name == "web_search":
        return await asyncio.to_thread(tools.web_search, args["query"])
    if name == "get_weather":
        return await tools.weather(args["city"])
    if name == "get_news":
        return await asyncio.to_thread(tools.news, args["topic"])
    return {"error": "unknown tool"}


def _error_detail(resp: httpx.Response) -> str:
    try:
        data = resp.json()
        error = data.get("error")
        if isinstance(error, dict):
            message = error.get("message")
            if message:
                return str(message)[:300]
        if data.get("detail"):
            return str(data["detail"])[:300]
    except Exception:
        pass
    return resp.text[:300] if resp.text else f"HTTP {resp.status_code}"


async def _complete(messages: list, with_tools: bool = True) -> dict:
    payload = {
        "model": config.MODEL,
        "messages": messages,
        "temperature": config.TEMPERATURE,
        "max_tokens": config.MAX_TOKENS,
    }
    if with_tools:
        payload["tools"] = TOOLS
    if config.REASONING_EFFORT:
        payload["reasoning_effort"] = config.REASONING_EFFORT

    headers = {"Authorization": f"Bearer {config.GROQ_API_KEY}"}
    url = f"{config.GROQ_BASE_URL}/chat/completions"
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(url, headers=headers, json=payload)
    except httpx.HTTPError:
        raise HTTPException(502, "Cannot reach the Groq API from the server")

    if resp.status_code == 400 and with_tools:
        detail = _error_detail(resp)
        if "tool" in detail.lower() or "function" in detail.lower():
            return await _complete(messages, False)

    if resp.status_code >= 400:
        raise HTTPException(502, f"Groq error: {_error_detail(resp)}")

    try:
        return resp.json()
    except ValueError:
        raise HTTPException(502, "Groq returned an invalid response")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "ai_configured": bool(config.GROQ_API_KEY),
        "model": config.MODEL,
    }


@app.post("/chat", response_model=ChatResponse, dependencies=guard)
async def chat(req: ChatRequest):
    if not config.GROQ_API_KEY:
        raise HTTPException(503, "GROQ_API_KEY is not configured on the server")

    system = build_system_prompt(req.language, req.personality, req.memory)
    messages = [{"role": "system", "content": system}]
    messages.extend(m.model_dump() for m in req.messages)
    used: list[str] = []

    for _ in range(4):
        data = await _complete(messages)
        choices = data.get("choices") or []
        if not choices:
            raise HTTPException(502, "Groq returned an empty response")

        choice = choices[0] or {}
        message = choice.get("message") or {}
        tool_calls = message.get("tool_calls") or []

        if not tool_calls:
            content = (message.get("content") or "").strip()
            if not content:
                if choice.get("finish_reason") == "length":
                    raise HTTPException(502, "AI reply was cut off. Increase MAYA_MAX_TOKENS.")
                raise HTTPException(502, "AI returned an empty reply")
            return ChatResponse(reply=content, used_tools=used)

        messages.append(
            {
                "role": "assistant",
                "content": message.get("content"),
                "tool_calls": tool_calls,
            }
        )

        for call in tool_calls:
            function = call.get("function") or {}
            name = function.get("name") or ""
            raw_args = function.get("arguments") or "{}"
            used.append(name)
            try:
                args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                if not isinstance(args, dict):
                    raise ValueError("invalid tool arguments")
                output = await run_tool(name, args)
            except Exception as e:
                output = {"error": str(e) or "tool failed"}
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.get("id", ""),
                    "name": name,
                    "content": json.dumps(output, ensure_ascii=False),
                }
            )

    raise HTTPException(500, "Too many tool rounds")


@app.get("/search", dependencies=guard)
async def search(q: str):
    return {"results": tools.web_search(q)}


@app.get("/weather", dependencies=guard)
async def weather(city: str):
    return await tools.weather(city)


@app.get("/news", dependencies=guard)
async def get_news(topic: str = "India"):
    return {"articles": tools.news(topic)}
