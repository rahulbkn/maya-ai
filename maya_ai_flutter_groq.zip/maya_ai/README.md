# MAYA AI
- `worker/` Cloudflare Worker (recommended): Groq proxy; the Groq key stays in Cloudflare secrets
- `backend/` FastAPI server (optional self-hosted alternative)
- `app/` Flutter app sources (lib + pubspec) - see docs/SETUP_STAGE2.md

## Deploy on Cloudflare Workers
    cd worker
    npm install
    npx wrangler login
    npx wrangler secret put GROQ_API_KEY
    npx wrangler secret put MAYA_APP_TOKEN
    npx wrangler deploy

The Worker URL will look like `https://maya-ai.<your-subdomain>.workers.dev`. Open `/health` to confirm it returns `status: ok` and `ai_configured: true`.

Set the model in `worker/wrangler.toml` (`MAYA_MODEL`, default `openai/gpt-oss-120b`). Rotate the Groq key or app token any time in Cloudflare dashboard -> Workers & Pages -> maya-ai -> Settings -> Variables and Secrets, then redeploy or save. The Flutter app only needs the Worker URL and the same app token in Settings.

Local testing:
    cd worker
    printf 'GROQ_API_KEY=your_key\nMAYA_APP_TOKEN=test-token\n' > .dev.vars
    npx wrangler dev

## Run the FastAPI backend (optional)
    cd backend
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    cp .env.example .env        # add GROQ_API_KEY and MAYA_APP_TOKEN
    uvicorn app.main:app --host 0.0.0.0 --port 8000

Change the model or rotate the key by editing `backend/.env` (`GROQ_API_KEY`, `MAYA_MODEL`) and restarting the server. No app rebuild is needed; keys never go inside the Flutter app.
